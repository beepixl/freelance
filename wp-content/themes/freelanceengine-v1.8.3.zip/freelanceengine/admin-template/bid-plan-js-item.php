<div class="sort-handle"></div>
<span>{{= sku }}</span> 
<span>{{= post_title }} <# if(typeof et_featured !== 'undefinded' && parseInt(et_featured) ){ #><em class="icon-text">^</em> <# } #></span>  
{{= backend_text }}
<div class="actions">
	<a href="#" title="Edit" class="icon act-edit" rel="665" data-icon="p"></a>
	<a href="#" title="Delete" class="icon act-del" rel="665" data-icon="D"></a>
</div>					
