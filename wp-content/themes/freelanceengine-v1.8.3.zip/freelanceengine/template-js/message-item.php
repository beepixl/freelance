<script type="text/template" id="ae-message-loop">
    <span class="message-avatar">{{= avatar }}</span>
    <div class="message-item">
        <p>{{= comment_content }}</p>
    </div>
</script>