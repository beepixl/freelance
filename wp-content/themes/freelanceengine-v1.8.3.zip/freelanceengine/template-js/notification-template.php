<script type="text/template" id="ae-notify-undo-template">
	<p class="fre-notify-archive"><?php _e('This notification has been archive.', ET_DOMAIN)?> <span><?php _e('Undo', ET_DOMAIN) ?></span></p>
</script>