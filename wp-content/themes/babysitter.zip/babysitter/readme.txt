Thank you for purchasing my theme. If you have any questions, please feel free to email via my user page contact form http://themeforest.net/user/dan_fisher
Thanks so much!