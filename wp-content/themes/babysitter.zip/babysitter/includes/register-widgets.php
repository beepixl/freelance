<?php 
require_once PARENT_DIR . '/includes/widgets/twitter_widget.php';
require_once PARENT_DIR . '/includes/widgets/flickr_widget.php';
require_once PARENT_DIR . '/includes/widgets/posts_widget.php';
require_once PARENT_DIR . '/includes/widgets/social_links.php';