<!-- search -->
<form class="search-form inline-form clearfix" method="get" action="<?php echo home_url(); ?>" role="search">
	<input class="search-input" type="search" name="s" placeholder="<?php _e( 'Search...', 'babysitter' ); ?>">
	<button class="search-submit" type="submit" role="button"><i class="icon-search"></i></button>
</form>
<!-- /search -->