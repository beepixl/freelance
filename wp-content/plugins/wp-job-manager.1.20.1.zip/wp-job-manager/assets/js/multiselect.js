jQuery(function(){
	jQuery( '.job-manager-multiselect' ).chosen();
});