<li class="indeed_attribution job_listing">
	<a href="http://www.indeed.com/">jobs by <img src="<?php echo JOB_MANAGER_INDEED_PLUGIN_URL . '/assets/images/jobsearch.gif'; ?>" style="border: 0; vertical-align: middle;" alt="Indeed job search"></a>
</li>