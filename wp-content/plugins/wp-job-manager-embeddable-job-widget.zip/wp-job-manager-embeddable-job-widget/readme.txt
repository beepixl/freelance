=== WP Job Manager - Embeddable Job Widget ===
Contributors: mikejolley
Requires at least: 3.8
Tested up to: 4.1
Stable tag: 1.0.2
License: GNU General Public License v3.0

Lets users generate and embed a widget containing your job listings on their own sites via a form added to your site with the shortcode [embeddable_job_widget_generator].

= Documentation =

Usage instructions for this plugin can be found on the documentation site: [https://wpjobmanager.com/documentation/add-ons/embeddable-job-widget](https://wpjobmanager.com/documentation/add-ons/embeddable-job-widget).

== Installation ==

To install this plugin, please refer to the guide here: [http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation)

== Changelog ==

= 1.0.2 =
* Fixed shortcode output.

= 1.0.1 =
* Fix preview in firefox.

= 1.0.0 =
* First release.