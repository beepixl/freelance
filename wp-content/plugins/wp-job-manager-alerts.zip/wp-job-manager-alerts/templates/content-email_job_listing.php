
<?php the_title(); ?>: <?php the_job_permalink(); ?>


** <?php _e( 'Job Type:', 'wp-job-manager-alerts' ); ?> <?php the_job_type(); ?>

** <?php _e( 'Company:', 'wp-job-manager-alerts' ); ?> <?php the_company_name(); ?>

** <?php _e( 'Location:', 'wp-job-manager-alerts' ); ?> <?php the_job_location( false ); ?>


----
